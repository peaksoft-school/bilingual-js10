import { GUI } from "https://cdn.skypack.dev/dat.gui";

const CONFIG = {
  "rotate-x": -24,
  "rotate-y": -32,
  height: 40,
  width: 20,
  depth: 20,
  packaged: true,
};

const UPDATE = () =>
  Object.keys(CONFIG).forEach((key) =>
    document.documentElement.style.setProperty(
      `--${key}`,
      typeof CONFIG[key] === "boolean" ? (CONFIG[key] ? 1 : 0) : CONFIG[key]
    )
  );

const CTRL = new GUI();
const RTO = CTRL.addFolder("Rotation");
RTO.add(CONFIG, "rotate-x", -90, 90, 1).onChange(UPDATE).name("X");
RTO.add(CONFIG, "rotate-y", -90, 90, 1).onChange(UPDATE).name("Y");

const SIZE = CTRL.addFolder("Size");
SIZE.add(CONFIG, "height", 10, 50, 1).onChange(UPDATE).name("Height");
SIZE.add(CONFIG, "width", 10, 50, 1).onChange(UPDATE).name("Width");
SIZE.add(CONFIG, "depth", 10, 50, 1).onChange(UPDATE).name("Depth");

CTRL.add(CONFIG, "packaged").onChange(UPDATE).name("Package?");

UPDATE();

